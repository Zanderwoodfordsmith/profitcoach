/**
 * LinkedIn profile page: extract visible fields + insert text into composers.
 */

(function () {
  const BTN_ID = "pc-linkedin-open-panel";

  function textOf(el) {
    return (el?.textContent || "").replace(/\s+/g, " ").trim();
  }

  function firstText(selectors) {
    for (const sel of selectors) {
      try {
        const el = document.querySelector(sel);
        const t = textOf(el);
        if (t) return t;
      } catch {
        // bad selector
      }
    }
    return "";
  }

  function canonicalProfileUrl() {
    try {
      const u = new URL(window.location.href);
      const parts = u.pathname.split("/").filter(Boolean);
      const inIdx = parts.findIndex((p) => p.toLowerCase() === "in");
      if (inIdx < 0 || !parts[inIdx + 1]) return null;
      const slug = decodeURIComponent(parts[inIdx + 1].replace(/\/+$/, ""));
      if (!slug) return null;
      return `https://www.linkedin.com/in/${slug}`;
    } catch {
      return null;
    }
  }

  function nameFromTitle() {
    const title = (document.title || "").trim();
    if (!title) return "";
    // "Jane Doe | LinkedIn" or "Jane Doe - Experience - LinkedIn"
    const cleaned = title
      .replace(/\s*[\|–—-]\s*LinkedIn.*$/i, "")
      .replace(/\s*[\|–—-]\s*(Experience|About|Activity).*$/i, "")
      .trim();
    if (cleaned && cleaned.length < 80 && !/linkedin/i.test(cleaned)) {
      return cleaned;
    }
    return "";
  }

  function extractCompanyFromHeadline(headline) {
    if (!headline) return "";
    const at = headline.match(/\sat\s+(.+)$/i);
    if (at?.[1]) return at[1].trim();
    return "";
  }

  function extractProfile() {
    const linkedinUrl = canonicalProfileUrl();
    let fullName =
      firstText([
        "main h1",
        "h1.text-heading-xlarge",
        "h1.top-card-layout__title",
        ".pv-text-details__left-panel h1",
        ".ph5 h1",
        "[data-generated-suggestion-target] h1",
      ]) || nameFromTitle();

    // Drop trailing "1st/2nd/3rd" degree badges sometimes glued into h1
    fullName = fullName
      .replace(/\s+(1st|2nd|3rd|Premium).*$/i, "")
      .replace(/\s+/g, " ")
      .trim();

    const headline =
      firstText([
        ".text-body-medium.break-words",
        ".top-card-layout__headline",
        ".pv-text-details__left-panel .text-body-medium",
        "div.text-body-medium.break-words",
      ]) || "";

    let location =
      firstText([
        ".text-body-small.inline.t-black--light.break-words",
        ".pv-text-details__left-panel .text-body-small",
        ".top-card__subline-item",
      ]) || "";
    if (location.length > 80) location = location.slice(0, 80);

    let businessName =
      firstText([
        'button[aria-label*="Current company"]',
        ".pv-text-details__right-panel button",
        'section[id*="experience"] span[aria-hidden="true"]',
      ]) || extractCompanyFromHeadline(headline);

    const about =
      firstText([
        "#about ~ div .inline-show-more-text",
        'section[id*="about"] .inline-show-more-text',
        '#about ~ div span[aria-hidden="true"]',
      ]) || "";

    let photoUrl = "";
    const img =
      document.querySelector(
        'img.pv-top-card-profile-picture__image, img.profile-photo-edit__preview, img[src*="profile-displayphoto"], button img[src*="profile"]'
      ) || null;
    if (img?.src) photoUrl = img.src;

    let jobTitle = headline;
    const atMatch = headline.match(/^(.+?)\s+at\s+/i);
    if (atMatch?.[1]) jobTitle = atMatch[1].trim();

    const firstName = fullName ? fullName.split(/\s+/)[0] : "";

    return {
      linkedinUrl,
      fullName,
      firstName,
      jobTitle: jobTitle || null,
      businessName: businessName || null,
      headline: headline || null,
      location: location || null,
      about: about ? about.slice(0, 2000) : null,
      photoUrl: photoUrl || null,
      pageUrl: window.location.href,
    };
  }

  function publishProfile() {
    const profile = extractProfile();
    chrome.runtime
      .sendMessage({ type: "PROFILE_CONTEXT", profile })
      .catch(() => {});
    return profile;
  }

  function ensureButton() {
    if (document.getElementById(BTN_ID)) return;
    if (!/\/in\//i.test(location.pathname)) return;
    const btn = document.createElement("button");
    btn.id = BTN_ID;
    btn.type = "button";
    btn.textContent = "Profit Coach";
    btn.setAttribute("aria-label", "Open Profit Coach");
    Object.assign(btn.style, {
      position: "fixed",
      right: "16px",
      bottom: "16px",
      zIndex: "2147483646",
      border: "none",
      borderRadius: "999px",
      padding: "11px 16px",
      background: "#0c1b2a",
      color: "#f8fafc",
      font: "600 13px/1.2 ui-sans-serif, system-ui, sans-serif",
      boxShadow: "0 10px 28px rgba(12,27,42,0.35)",
      cursor: "pointer",
    });
    btn.addEventListener("click", () => {
      publishProfile();
      chrome.runtime.sendMessage({ type: "OPEN_SIDE_PANEL" }).catch(() => {});
    });
    document.documentElement.appendChild(btn);
  }

  function findEditableComposer() {
    const selectors = [
      'div.msg-form__contenteditable[contenteditable="true"]',
      'div[role="textbox"][contenteditable="true"]',
      'textarea[name="message"]',
      "textarea.connect-button-send-invite__custom-message",
      'div.ql-editor[contenteditable="true"]',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.offsetParent !== null) return el;
    }
    const dialog = document.querySelector('[role="dialog"]');
    if (dialog) {
      const ed = dialog.querySelector('[contenteditable="true"], textarea');
      if (ed) return ed;
    }
    return null;
  }

  function insertText(text) {
    const el = findEditableComposer();
    if (!el) {
      return {
        ok: false,
        error: "Open Connect or Messaging on LinkedIn first, then Insert.",
      };
    }
    el.focus();
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      el.value = text;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { ok: true };
    }
    try {
      document.execCommand("selectAll", false);
      document.execCommand("insertText", false, text);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, data: text }));
      return { ok: true };
    } catch {
      el.textContent = text;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      return { ok: true };
    }
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "GET_PROFILE") {
      sendResponse({ ok: true, profile: publishProfile() });
      return false;
    }
    if (message?.type === "INSERT_TEXT") {
      sendResponse(insertText(String(message.text || "")));
      return false;
    }
    return false;
  });

  let lastUrl = location.href;
  function tick() {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      if (/\/in\//i.test(location.pathname)) {
        ensureButton();
        setTimeout(() => publishProfile(), 500);
      }
    }
  }

  ensureButton();
  setTimeout(() => publishProfile(), 400);
  setTimeout(() => publishProfile(), 1500);
  setInterval(tick, 800);

  const obs = new MutationObserver(() => ensureButton());
  obs.observe(document.documentElement, { childList: true, subtree: true });
})();
