/**
 * Profit Coach for LinkedIn — background service worker.
 * Cookies (Sales Nav session) + side panel + auth token lookup.
 */

chrome.runtime.onInstalled.addListener(() => {
  void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "GET_LINKEDIN_COOKIES") {
    void collectLinkedInCookies()
      .then((cookies) => sendResponse({ ok: true, cookies }))
      .catch((err) =>
        sendResponse({
          ok: false,
          error: err instanceof Error ? err.message : "Cookie read failed.",
        })
      );
    return true;
  }

  if (message?.type === "OPEN_SIDE_PANEL") {
    const tabId = sender.tab?.id;
    if (typeof tabId !== "number") {
      sendResponse({ ok: false, error: "No tab." });
      return false;
    }
    void chrome.sidePanel
      .open({ tabId })
      .then(() => sendResponse({ ok: true }))
      .catch((err) =>
        sendResponse({
          ok: false,
          error: err instanceof Error ? err.message : "Could not open panel.",
        })
      );
    return true;
  }

  if (message?.type === "PROFILE_CONTEXT") {
    const profile = message.profile ?? null;
    void chrome.storage.session
      .set({
        lastProfile: profile,
        lastProfileAt: Date.now(),
        lastProfileTabId: sender.tab?.id ?? null,
      })
      .then(() => {
        // Notify open side panel pages.
        chrome.runtime
          .sendMessage({ type: "PROFILE_UPDATED", profile })
          .catch(() => {});
        sendResponse({ ok: true });
      });
    return true;
  }

  if (message?.type === "GET_STORED_PROFILE") {
    void chrome.storage.session.get(
      ["lastProfile", "lastProfileAt", "lastProfileTabId"],
      (stored) => {
        sendResponse({
          ok: true,
          profile: stored.lastProfile ?? null,
          at: stored.lastProfileAt ?? null,
          tabId: stored.lastProfileTabId ?? null,
        });
      }
    );
    return true;
  }

  if (message?.type === "FIND_ACCESS_TOKEN") {
    void findAccessToken(message.origin)
      .then((result) => sendResponse(result))
      .catch((err) =>
        sendResponse({
          ok: false,
          error: err instanceof Error ? err.message : "Auth lookup failed.",
        })
      );
    return true;
  }

  if (message?.type === "INSERT_LINKEDIN_TEXT") {
    const tabId = message.tabId ?? sender.tab?.id;
    if (typeof tabId !== "number") {
      sendResponse({ ok: false, error: "No LinkedIn tab." });
      return false;
    }
    void chrome.tabs
      .sendMessage(tabId, {
        type: "INSERT_TEXT",
        text: message.text ?? "",
      })
      .then((res) => sendResponse(res ?? { ok: true }))
      .catch(() =>
        sendResponse({
          ok: false,
          error: "Refresh the LinkedIn profile tab and try again.",
        })
      );
    return true;
  }

  return false;
});

async function collectLinkedInCookies() {
  const cookies = await chrome.cookies.getAll({ domain: "linkedin.com" });
  if (!cookies.length) {
    throw new Error(
      "No LinkedIn cookies found. Open linkedin.com / Sales Navigator and log in first."
    );
  }

  const hasLiAt = cookies.some((c) => c.name === "li_at" && c.value);
  if (!hasLiAt) {
    throw new Error(
      "LinkedIn login cookie (li_at) missing. Log into LinkedIn in this browser, then try again."
    );
  }

  return cookies.map((c) => ({
    domain: c.domain,
    expirationDate: c.expirationDate,
    hostOnly: c.hostOnly,
    httpOnly: c.httpOnly,
    name: c.name,
    path: c.path,
    sameSite:
      c.sameSite === "no_restriction"
        ? "no_restriction"
        : c.sameSite === "lax"
          ? "lax"
          : c.sameSite === "strict"
            ? "strict"
            : "unspecified",
    secure: c.secure,
    session: c.session,
    storeId: c.storeId || "0",
    value: c.value,
  }));
}

function originCandidates(origin) {
  const list = [origin];
  try {
    const u = new URL(origin);
    if (u.hostname === "localhost") {
      list.push(
        `${u.protocol}//127.0.0.1:${u.port || (u.protocol === "https:" ? "443" : "80")}`
      );
    } else if (u.hostname === "127.0.0.1") {
      list.push(
        `${u.protocol}//localhost:${u.port || (u.protocol === "https:" ? "443" : "80")}`
      );
    }
  } catch {
    // ignore
  }
  return [...new Set(list)];
}

function readSupabaseAccessTokenInPage() {
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (!key || !key.startsWith("sb-") || !key.endsWith("-auth-token")) continue;
    const raw = localStorage.getItem(key);
    if (!raw) continue;
    try {
      const parsed = JSON.parse(raw);
      const access =
        parsed?.access_token ||
        parsed?.currentSession?.access_token ||
        parsed?.session?.access_token;
      if (typeof access === "string" && access.length > 20) return access;
    } catch {
      // ignore
    }
  }
  return null;
}

async function findAppTab(origin) {
  const candidates = originCandidates(origin);
  const tabs = await chrome.tabs.query({});
  return (
    tabs.find(
      (t) =>
        typeof t.id === "number" &&
        t.url &&
        candidates.some((o) => t.url.startsWith(o))
    ) || null
  );
}

async function findAccessToken(origin) {
  const match = await findAppTab(origin);
  if (!match?.id) {
    return {
      ok: false,
      error: `No open tab for ${String(origin).replace(/^https?:\/\//, "")}. Open Profit Coach there and sign in.`,
    };
  }

  try {
    const injected = await chrome.scripting.executeScript({
      target: { tabId: match.id },
      func: readSupabaseAccessTokenInPage,
    });
    const token = injected?.[0]?.result;
    if (typeof token === "string" && token.length > 20) {
      return {
        ok: true,
        accessToken: token,
        originUsed: new URL(match.url).origin,
      };
    }
  } catch (err) {
    console.warn("executeScript failed", err);
  }

  try {
    const res = await chrome.tabs.sendMessage(match.id, {
      type: "GET_SUPABASE_ACCESS_TOKEN",
    });
    if (res?.ok && res.accessToken) {
      return {
        ok: true,
        accessToken: res.accessToken,
        originUsed: res.origin || new URL(match.url).origin,
      };
    }
    return {
      ok: false,
      error:
        "Profit Coach tab is open but you’re not signed in there. Sign in, then try again.",
    };
  } catch {
    return {
      ok: false,
      error:
        "Couldn’t read your Profit Coach login from that tab. Refresh the app tab once, then retry.",
    };
  }
}
