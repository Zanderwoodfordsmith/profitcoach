/* global PC_LINKEDIN_EXT */

const cfg = globalThis.PC_LINKEDIN_EXT;

const originEl = document.getElementById("origin");
const authStatusEl = document.getElementById("authStatus");
const profileEmpty = document.getElementById("profileEmpty");
const profileBlock = document.getElementById("profileBlock");
const pName = document.getElementById("pName");
const pMeta = document.getElementById("pMeta");
const pAbout = document.getElementById("pAbout");
const stageEl = document.getElementById("stage");
const saveBtn = document.getElementById("saveBtn");
const saveStatus = document.getElementById("saveStatus");
const workspaceLink = document.getElementById("workspaceLink");
const draftConnector = document.getElementById("draftConnector");
const draftDm = document.getElementById("draftDm");
const draftStatus = document.getElementById("draftStatus");
const draftsEl = document.getElementById("drafts");

let profile = null;
let accessToken = null;
let apiOrigin = null;
let entitlementOk = false;
let profileTabId = null;

function setBanner(text, kind) {
  authStatusEl.textContent = text;
  authStatusEl.className = "banner" + (kind ? ` ${kind}` : "");
}

function setSaveStatus(text, kind) {
  saveStatus.textContent = text || "";
  saveStatus.className = "status" + (kind ? ` ${kind}` : "");
}

function setDraftStatus(text, kind) {
  draftStatus.textContent = text || "";
  draftStatus.className = "status" + (kind ? ` ${kind}` : "");
}

function fillOrigins() {
  originEl.innerHTML = "";
  for (const origin of cfg.APP_ORIGINS) {
    const opt = document.createElement("option");
    opt.value = origin;
    opt.textContent = origin.replace(/^https?:\/\//, "");
    originEl.appendChild(opt);
  }
  chrome.storage.local.get(["preferredOrigin"], (stored) => {
    if (
      stored.preferredOrigin &&
      cfg.APP_ORIGINS.includes(stored.preferredOrigin)
    ) {
      originEl.value = stored.preferredOrigin;
    } else {
      originEl.value = "http://localhost:3002";
    }
  });
}

originEl.addEventListener("change", () => {
  chrome.storage.local.set({ preferredOrigin: originEl.value });
  void refreshAuth();
});

function renderProfile(next) {
  profile = next;
  workspaceLink.classList.add("hidden");
  workspaceLink.innerHTML = "";
  setSaveStatus("");

  if (!profile?.fullName || !profile?.linkedinUrl) {
    profileEmpty.classList.remove("hidden");
    profileBlock.classList.add("hidden");
    return;
  }

  profileEmpty.classList.add("hidden");
  profileBlock.classList.remove("hidden");
  pName.textContent = profile.fullName;
  const bits = [
    profile.jobTitle || profile.headline,
    profile.businessName,
    profile.location,
  ].filter(Boolean);
  pMeta.textContent = bits.join(" · ");
  pAbout.textContent = profile.about || "";
  updateActionEnabled();
}

function updateActionEnabled() {
  const ready = Boolean(
    entitlementOk && profile?.fullName && profile?.linkedinUrl
  );
  saveBtn.disabled = !ready;
  draftConnector.disabled = !ready;
  draftDm.disabled = !ready;
}

async function refreshAuth() {
  setBanner("Looking for your Profit Coach login…");
  entitlementOk = false;
  accessToken = null;
  apiOrigin = null;
  updateActionEnabled();

  const auth = await chrome.runtime.sendMessage({
    type: "FIND_ACCESS_TOKEN",
    origin: originEl.value,
  });

  if (!auth?.ok) {
    setBanner(
      auth?.error ||
        "Open Profit Coach in another tab and sign in, then reopen this panel.",
      "err"
    );
    return;
  }

  accessToken = auth.accessToken;
  apiOrigin = auth.originUsed || originEl.value;

  try {
    const res = await fetch(`${apiOrigin}${cfg.ACCESS_PATH}`, {
      headers: { Authorization: `Bearer ${accessToken}` },
      cache: "no-store",
    });
    const body = await res.json().catch(() => ({}));

    if (res.ok && body.allowed) {
      entitlementOk = true;
      setBanner("Signed in · marketing access OK", "ok");
      updateActionEnabled();
      return;
    }

    if (body.code === "tier_required") {
      setBanner(
        "Your membership doesn’t include marketing tools. Upgrade in Profit Coach to use Save & Draft.",
        "warn"
      );
    } else if (body.code === "allowlist") {
      setBanner(
        "Extension beta isn’t enabled for this account yet.",
        "warn"
      );
    } else {
      setBanner(body.error || "Not authorized for this extension.", "err");
    }
  } catch {
    setBanner("Could not reach Profit Coach. Check the App origin.", "err");
  }
  updateActionEnabled();
}

async function onSave() {
  if (!entitlementOk || !profile || !accessToken || !apiOrigin) return;
  saveBtn.disabled = true;
  setSaveStatus("Saving…");
  try {
    const res = await fetch(`${apiOrigin}${cfg.SAVE_PATH}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        linkedinUrl: profile.linkedinUrl,
        fullName: profile.fullName,
        jobTitle: profile.jobTitle,
        businessName: profile.businessName,
        headline: profile.headline,
        location: profile.location,
        about: profile.about,
        photoUrl: profile.photoUrl,
        prospectStatus: stageEl.value || "new",
      }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (body.code === "tier_required") {
        entitlementOk = false;
        setBanner(
          "Membership required. Upgrade in Profit Coach to keep using this.",
          "warn"
        );
      }
      throw new Error(body.error || `Save failed (${res.status}).`);
    }
    setSaveStatus(
      body.created ? "Saved to your pipeline." : "Updated existing prospect.",
      "ok"
    );
    if (body.workspaceUrl) {
      workspaceLink.classList.remove("hidden");
      workspaceLink.innerHTML = `<a href="${body.workspaceUrl}" target="_blank" rel="noreferrer">Open in Profit Coach</a>`;
    }
  } catch (err) {
    setSaveStatus(err instanceof Error ? err.message : "Save failed.", "err");
  } finally {
    updateActionEnabled();
  }
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
    return true;
  }
}

async function onDraft(kind) {
  if (!entitlementOk || !profile || !accessToken || !apiOrigin) return;
  draftConnector.disabled = true;
  draftDm.disabled = true;
  draftsEl.innerHTML = "";
  setDraftStatus("Drafting…");
  try {
    const res = await fetch(`${apiOrigin}${cfg.DRAFT_PATH}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        kind,
        fullName: profile.fullName,
        firstName: profile.firstName,
        jobTitle: profile.jobTitle,
        businessName: profile.businessName,
        headline: profile.headline,
        location: profile.location,
        about: profile.about,
        linkedinUrl: profile.linkedinUrl,
      }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (body.code === "tier_required") {
        entitlementOk = false;
        setBanner(
          "Membership required. Upgrade in Profit Coach to keep using this.",
          "warn"
        );
      }
      throw new Error(body.error || `Draft failed (${res.status}).`);
    }
    const variants = Array.isArray(body.variants) ? body.variants : [];
    if (!variants.length) throw new Error("No drafts returned.");
    setDraftStatus(`${variants.length} variants ready. Review before sending.`, "ok");
    for (const v of variants) {
      const card = document.createElement("div");
      card.className = "draft";
      const title = document.createElement("h3");
      title.textContent = v.label || "Variant";
      const pre = document.createElement("pre");
      pre.textContent = v.body || "";
      const actions = document.createElement("div");
      actions.className = "draft-actions";
      const copyBtn = document.createElement("button");
      copyBtn.type = "button";
      copyBtn.className = "secondary";
      copyBtn.textContent = "Copy";
      copyBtn.addEventListener("click", () => {
        void copyText(v.body || "").then(() =>
          setDraftStatus("Copied.", "ok")
        );
      });
      const insertBtn = document.createElement("button");
      insertBtn.type = "button";
      insertBtn.className = "secondary";
      insertBtn.textContent = "Insert into LinkedIn";
      insertBtn.addEventListener("click", () => {
        void chrome.runtime
          .sendMessage({
            type: "INSERT_LINKEDIN_TEXT",
            text: v.body || "",
            tabId: profileTabId,
          })
          .then((r) => {
            if (r?.ok) setDraftStatus("Inserted — click Send on LinkedIn.", "ok");
            else {
              void copyText(v.body || "");
              setDraftStatus(
                (r?.error || "Could not insert.") + " Copied instead.",
                "warn"
              );
            }
          });
      });
      actions.append(copyBtn, insertBtn);
      card.append(title, pre, actions);
      draftsEl.appendChild(card);
    }
  } catch (err) {
    setDraftStatus(err instanceof Error ? err.message : "Draft failed.", "err");
  } finally {
    updateActionEnabled();
  }
}

async function loadStoredProfile() {
  const stored = await chrome.runtime.sendMessage({ type: "GET_STORED_PROFILE" });
  if (stored?.profile) {
    profileTabId = stored.tabId ?? null;
    renderProfile(stored.profile);
  }
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "PROFILE_UPDATED") {
    renderProfile(message.profile ?? null);
  }
});

fillOrigins();
saveBtn.addEventListener("click", () => void onSave());
draftConnector.addEventListener("click", () => void onDraft("connector"));
draftDm.addEventListener("click", () => void onDraft("dm"));

void (async () => {
  await loadStoredProfile();
  await refreshAuth();
})();
