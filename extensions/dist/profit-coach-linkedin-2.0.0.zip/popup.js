/* global PC_LINKEDIN_EXT */

const statusEl = document.getElementById("status");
const accessEl = document.getElementById("access");
const originEl = document.getElementById("origin");
const saveBtn = document.getElementById("save");
const copyBtn = document.getElementById("copy");
const openPanelBtn = document.getElementById("openPanel");

const cfg = globalThis.PC_LINKEDIN_EXT;

function setStatus(text, kind) {
  statusEl.textContent = text;
  statusEl.className = "status" + (kind ? ` ${kind}` : "");
}

function setAccess(text, kind) {
  accessEl.textContent = text;
  accessEl.className = "status" + (kind ? ` ${kind}` : "");
}

function fillOrigins() {
  originEl.innerHTML = "";
  for (const origin of cfg.APP_ORIGINS) {
    const opt = document.createElement("option");
    opt.value = origin;
    opt.textContent = origin.replace(/^https?:\/\//, "");
    originEl.appendChild(opt);
  }
  chrome.storage.local.get(["preferredOrigin"], (stored) => {
    if (
      stored.preferredOrigin &&
      cfg.APP_ORIGINS.includes(stored.preferredOrigin)
    ) {
      originEl.value = stored.preferredOrigin;
    } else {
      originEl.value = "http://localhost:3002";
    }
    void refreshAccess();
  });
}

originEl.addEventListener("change", () => {
  chrome.storage.local.set({ preferredOrigin: originEl.value });
  void refreshAccess();
});

async function getLinkedInCookieJson() {
  const res = await chrome.runtime.sendMessage({ type: "GET_LINKEDIN_COOKIES" });
  if (!res?.ok) throw new Error(res?.error || "Could not read LinkedIn cookies.");
  return JSON.stringify(res.cookies);
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return;
  } catch {
    // fallback
  }
  const ta = document.createElement("textarea");
  ta.value = text;
  document.body.appendChild(ta);
  ta.select();
  document.execCommand("copy");
  ta.remove();
}

async function refreshAccess() {
  setAccess("Checking login…");
  const auth = await chrome.runtime.sendMessage({
    type: "FIND_ACCESS_TOKEN",
    origin: originEl.value,
  });
  if (!auth?.ok) {
    setAccess(auth?.error || "Sign in to Profit Coach in another tab.", "err");
    return;
  }
  try {
    const res = await fetch(`${auth.originUsed || originEl.value}${cfg.ACCESS_PATH}`, {
      headers: { Authorization: `Bearer ${auth.accessToken}` },
      cache: "no-store",
    });
    const body = await res.json().catch(() => ({}));
    if (res.ok && body.allowed) {
      setAccess("Signed in · Save & Draft available", "ok");
      return;
    }
    if (body.code === "tier_required") {
      setAccess("Membership upgrade needed for Save & Draft.", "err");
    } else if (body.code === "allowlist") {
      setAccess("Beta not enabled for this account yet.", "err");
    } else {
      setAccess(body.error || "Not authorized.", "err");
    }
  } catch {
    setAccess("Could not reach Profit Coach.", "err");
  }
}

async function onCopy() {
  copyBtn.disabled = true;
  saveBtn.disabled = true;
  setStatus("Reading LinkedIn cookies…");
  try {
    const json = await getLinkedInCookieJson();
    await copyToClipboard(json);
    setStatus(
      "Copied. Paste into Lead Finder → Session if save-to-account isn’t available.",
      "ok"
    );
  } catch (err) {
    setStatus(err instanceof Error ? err.message : "Copy failed.", "err");
  } finally {
    copyBtn.disabled = false;
    saveBtn.disabled = false;
  }
}

async function onSave() {
  copyBtn.disabled = true;
  saveBtn.disabled = true;
  setStatus("Reading LinkedIn cookies…");
  try {
    const cookie = await getLinkedInCookieJson();
    const origin = originEl.value;
    setStatus("Looking for your Profit Coach login…");
    const auth = await chrome.runtime.sendMessage({
      type: "FIND_ACCESS_TOKEN",
      origin,
    });
    if (!auth?.ok) {
      await copyToClipboard(cookie);
      setStatus(
        `${auth?.error || "Not signed in."} Cookies were copied to the clipboard instead.`,
        "err"
      );
      return;
    }

    const apiOrigin = auth.originUsed || origin;
    setStatus("Saving session to your account…");
    const res = await fetch(`${apiOrigin}${cfg.SESSION_PATH}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${auth.accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        cookie,
        userAgent: navigator.userAgent,
      }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) {
      await copyToClipboard(cookie);
      throw new Error(
        (body.error || `Save failed (${res.status}).`) +
          " Cookies were copied so you can paste them."
      );
    }
    setStatus(
      "Saved to your Profit Coach account. You can import from Lead Finder.",
      "ok"
    );
  } catch (err) {
    setStatus(err instanceof Error ? err.message : "Save failed.", "err");
  } finally {
    copyBtn.disabled = false;
    saveBtn.disabled = false;
  }
}

async function onOpenPanel() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    setStatus("No active tab.", "err");
    return;
  }
  try {
    await chrome.sidePanel.open({ tabId: tab.id });
    window.close();
  } catch (err) {
    setStatus(
      err instanceof Error ? err.message : "Could not open side panel.",
      "err"
    );
  }
}

fillOrigins();
copyBtn.addEventListener("click", () => void onCopy());
saveBtn.addEventListener("click", () => void onSave());
openPanelBtn.addEventListener("click", () => void onOpenPanel());
