/**
 * LinkedIn profile page: extract visible fields + insert text into composers.
 */

(function () {
  const BTN_ID = "pc-linkedin-open-panel";

  function textOf(el) {
    return (el?.textContent || "").replace(/\s+/g, " ").trim();
  }

  function firstText(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      const t = textOf(el);
      if (t) return t;
    }
    return "";
  }

  function canonicalProfileUrl() {
    try {
      const u = new URL(window.location.href);
      const parts = u.pathname.split("/").filter(Boolean);
      const inIdx = parts.findIndex((p) => p.toLowerCase() === "in");
      if (inIdx < 0 || !parts[inIdx + 1]) return null;
      const slug = decodeURIComponent(parts[inIdx + 1].replace(/\/+$/, ""));
      if (!slug) return null;
      return `https://www.linkedin.com/in/${slug}`;
    } catch {
      return null;
    }
  }

  function extractCompanyFromHeadline(headline) {
    if (!headline) return "";
    const at = headline.match(/\sat\s+(.+)$/i);
    if (at?.[1]) return at[1].trim();
    const pipe = headline.split("|").map((s) => s.trim());
    if (pipe.length > 1) return pipe[pipe.length - 1];
    return "";
  }

  function extractProfile() {
    const linkedinUrl = canonicalProfileUrl();
    const fullName =
      firstText([
        "h1.top-card-layout__title",
        "h1.text-heading-xlarge",
        ".pv-text-details__left-panel h1",
        "main h1",
      ]) || "";

    const headline =
      firstText([
        ".top-card-layout__headline",
        ".text-body-medium.break-words",
        ".pv-text-details__left-panel .text-body-medium",
        "div.text-body-medium.break-words",
      ]) || "";

    let location =
      firstText([
        ".top-card__subline-item",
        ".pv-text-details__left-panel .text-body-small",
        "span.text-body-small.inline.t-black--light.break-words",
      ]) || "";

    // Prefer a location-looking string (contains comma or known country words).
    if (location && location.length > 80) location = location.slice(0, 80);

    let businessName =
      firstText([
        'button[aria-label*="Current company"]',
        ".pv-text-details__right-panel button",
        "#experience ~ div .hoverable-link-text",
        'section[id*="experience"] a[data-field="experience_company_logo"] span[aria-hidden="true"]',
      ]) || extractCompanyFromHeadline(headline);

    const about =
      firstText([
        "#about ~ div .inline-show-more-text",
        'section[id*="about"] .inline-show-more-text',
        '#about ~ div span[aria-hidden="true"]',
      ]) || "";

    let photoUrl = "";
    const img =
      document.querySelector(
        ".pv-top-card-profile-picture__image, .profile-photo-edit__preview, img.pv-top-card__photo, button img[src*='profile']"
      ) || document.querySelector('img[src*="profile-displayphoto"]');
    if (img?.src) photoUrl = img.src;

    // jobTitle: headline before " at "
    let jobTitle = headline;
    const atMatch = headline.match(/^(.+?)\s+at\s+/i);
    if (atMatch?.[1]) jobTitle = atMatch[1].trim();

    const firstName = fullName ? fullName.split(/\s+/)[0] : "";

    return {
      linkedinUrl,
      fullName,
      firstName,
      jobTitle: jobTitle || null,
      businessName: businessName || null,
      headline: headline || null,
      location: location || null,
      about: about ? about.slice(0, 2000) : null,
      photoUrl: photoUrl || null,
      pageUrl: window.location.href,
    };
  }

  function publishProfile() {
    const profile = extractProfile();
    chrome.runtime.sendMessage({ type: "PROFILE_CONTEXT", profile }).catch(() => {});
    return profile;
  }

  function ensureButton() {
    if (document.getElementById(BTN_ID)) return;
    const btn = document.createElement("button");
    btn.id = BTN_ID;
    btn.type = "button";
    btn.textContent = "Profit Coach";
    btn.setAttribute("aria-label", "Open Profit Coach side panel");
    Object.assign(btn.style, {
      position: "fixed",
      right: "16px",
      bottom: "16px",
      zIndex: "2147483646",
      border: "none",
      borderRadius: "999px",
      padding: "10px 14px",
      background: "#0f172a",
      color: "#f8fafc",
      font: "600 13px/1.2 system-ui, -apple-system, sans-serif",
      boxShadow: "0 8px 24px rgba(15,23,42,0.28)",
      cursor: "pointer",
    });
    btn.addEventListener("click", () => {
      publishProfile();
      chrome.runtime.sendMessage({ type: "OPEN_SIDE_PANEL" }).catch(() => {});
    });
    document.documentElement.appendChild(btn);
  }

  function findEditableComposer() {
    const selectors = [
      'div.msg-form__contenteditable[contenteditable="true"]',
      'div[role="textbox"][contenteditable="true"]',
      'textarea[name="message"]',
      "textarea.connect-button-send-invite__custom-message",
      'div.ql-editor[contenteditable="true"]',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.offsetParent !== null) return el;
    }
    // Any visible contenteditable in a dialog
    const dialog = document.querySelector('[role="dialog"]');
    if (dialog) {
      const ed = dialog.querySelector('[contenteditable="true"], textarea');
      if (ed) return ed;
    }
    return null;
  }

  function insertText(text) {
    const el = findEditableComposer();
    if (!el) {
      return {
        ok: false,
        error:
          "No open message or connection note box. Open Connect / Messaging, then Insert again.",
      };
    }
    el.focus();
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      el.value = text;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { ok: true };
    }
    // contenteditable
    try {
      document.execCommand("selectAll", false);
      document.execCommand("insertText", false, text);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, data: text }));
      return { ok: true };
    } catch {
      el.textContent = text;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      return { ok: true };
    }
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "GET_PROFILE") {
      sendResponse({ ok: true, profile: publishProfile() });
      return false;
    }
    if (message?.type === "INSERT_TEXT") {
      sendResponse(insertText(String(message.text || "")));
      return false;
    }
    return false;
  });

  let lastUrl = location.href;
  function onNavigate() {
    if (location.href === lastUrl) return;
    lastUrl = location.href;
    if (/\/in\//i.test(location.pathname)) {
      ensureButton();
      setTimeout(() => publishProfile(), 800);
    }
  }

  ensureButton();
  setTimeout(() => publishProfile(), 600);
  setInterval(onNavigate, 1000);

  const obs = new MutationObserver(() => {
    ensureButton();
  });
  obs.observe(document.documentElement, { childList: true, subtree: true });
})();
