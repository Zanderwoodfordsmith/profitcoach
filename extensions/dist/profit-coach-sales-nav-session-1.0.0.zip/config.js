/* global globalThis */
/** Shared config for popup + background (classic scripts). */
globalThis.PC_SALES_NAV_EXT = {
  APP_ORIGINS: [
    "https://www.businesscoachacademy.com",
    "https://businesscoachacademy.com",
    "https://app.businesscoachacademy.com",
    "http://localhost:3002",
    "http://127.0.0.1:3002",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
  ],
  SESSION_PATH: "/api/sales-nav-session",
};
