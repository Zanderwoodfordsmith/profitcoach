/* global PC_SALES_NAV_EXT */

const statusEl = document.getElementById("status");
const originEl = document.getElementById("origin");
const saveBtn = document.getElementById("save");
const copyBtn = document.getElementById("copy");

const cfg = globalThis.PC_SALES_NAV_EXT;

function setStatus(text, kind) {
  statusEl.textContent = text;
  statusEl.className = "status" + (kind ? ` ${kind}` : "");
}

function fillOrigins() {
  originEl.innerHTML = "";
  for (const origin of cfg.APP_ORIGINS) {
    const opt = document.createElement("option");
    opt.value = origin;
    opt.textContent = origin.replace(/^https?:\/\//, "");
    originEl.appendChild(opt);
  }
  chrome.storage.local.get(["preferredOrigin"], (stored) => {
    if (
      stored.preferredOrigin &&
      cfg.APP_ORIGINS.includes(stored.preferredOrigin)
    ) {
      originEl.value = stored.preferredOrigin;
    } else {
      originEl.value = "http://localhost:3002";
    }
  });
}

originEl.addEventListener("change", () => {
  chrome.storage.local.set({ preferredOrigin: originEl.value });
});

async function getLinkedInCookieJson() {
  const res = await chrome.runtime.sendMessage({ type: "GET_LINKEDIN_COOKIES" });
  if (!res?.ok) throw new Error(res?.error || "Could not read LinkedIn cookies.");
  return JSON.stringify(res.cookies);
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return;
  } catch {
    // fallback
  }
  const ta = document.createElement("textarea");
  ta.value = text;
  document.body.appendChild(ta);
  ta.select();
  document.execCommand("copy");
  ta.remove();
}

/** Origins that should be treated as the same local app. */
function originCandidates(origin) {
  const list = [origin];
  try {
    const u = new URL(origin);
    if (u.hostname === "localhost") {
      list.push(`${u.protocol}//127.0.0.1:${u.port || (u.protocol === "https:" ? "443" : "80")}`);
    } else if (u.hostname === "127.0.0.1") {
      list.push(`${u.protocol}//localhost:${u.port || (u.protocol === "https:" ? "443" : "80")}`);
    }
  } catch {
    // ignore
  }
  return [...new Set(list)];
}

function readSupabaseAccessTokenInPage() {
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (!key || !key.startsWith("sb-") || !key.endsWith("-auth-token")) continue;
    const raw = localStorage.getItem(key);
    if (!raw) continue;
    try {
      const parsed = JSON.parse(raw);
      const access =
        parsed?.access_token ||
        parsed?.currentSession?.access_token ||
        parsed?.session?.access_token;
      if (typeof access === "string" && access.length > 20) return access;
    } catch {
      // ignore
    }
  }
  return null;
}

async function findAppTab(origin) {
  const candidates = originCandidates(origin);
  const tabs = await chrome.tabs.query({});
  return (
    tabs.find(
      (t) =>
        typeof t.id === "number" &&
        t.url &&
        candidates.some((o) => t.url.startsWith(o))
    ) || null
  );
}

async function findAccessToken(origin) {
  const match = await findAppTab(origin);
  if (!match?.id) {
    return {
      ok: false,
      error: `No open tab for ${origin.replace(/^https?:\/\//, "")}. Open Profit Coach there and sign in.`,
    };
  }

  // Prefer direct injection — works even if content script wasn’t loaded yet.
  try {
    const injected = await chrome.scripting.executeScript({
      target: { tabId: match.id },
      func: readSupabaseAccessTokenInPage,
    });
    const token = injected?.[0]?.result;
    if (typeof token === "string" && token.length > 20) {
      return { ok: true, accessToken: token, originUsed: new URL(match.url).origin };
    }
  } catch (err) {
    // Fall through to content-script message.
    console.warn("executeScript failed", err);
  }

  try {
    const res = await chrome.tabs.sendMessage(match.id, {
      type: "GET_SUPABASE_ACCESS_TOKEN",
    });
    if (res?.ok && res.accessToken) {
      return {
        ok: true,
        accessToken: res.accessToken,
        originUsed: res.origin || new URL(match.url).origin,
      };
    }
    return {
      ok: false,
      error:
        "Profit Coach tab is open but you’re not signed in there. Sign in, then try again.",
    };
  } catch {
    return {
      ok: false,
      error:
        "Couldn’t read your Profit Coach login from that tab. Refresh the app tab once, then retry.",
    };
  }
}

async function onCopy() {
  copyBtn.disabled = true;
  saveBtn.disabled = true;
  setStatus("Reading LinkedIn cookies…");
  try {
    const json = await getLinkedInCookieJson();
    await copyToClipboard(json);
    setStatus(
      "Copied. Paste into Lead Finder → Session if save-to-account isn’t available.",
      "ok"
    );
  } catch (err) {
    setStatus(err instanceof Error ? err.message : "Copy failed.", "err");
  } finally {
    copyBtn.disabled = false;
    saveBtn.disabled = false;
  }
}

async function onSave() {
  copyBtn.disabled = true;
  saveBtn.disabled = true;
  setStatus("Reading LinkedIn cookies…");
  try {
    const cookie = await getLinkedInCookieJson();
    const origin = originEl.value;
    setStatus("Looking for your Profit Coach login…");
    const auth = await findAccessToken(origin);
    if (!auth.ok) {
      await copyToClipboard(cookie);
      setStatus(`${auth.error} Cookies were copied to the clipboard instead.`, "err");
      return;
    }

    const apiOrigin = auth.originUsed || origin;
    setStatus("Saving session to your account…");
    const res = await fetch(`${apiOrigin}${cfg.SESSION_PATH}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${auth.accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        cookie,
        userAgent: navigator.userAgent,
      }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) {
      await copyToClipboard(cookie);
      throw new Error(
        (body.error || `Save failed (${res.status}).`) +
          " Cookies were copied so you can paste them."
      );
    }
    setStatus("Saved to your Profit Coach account. You can import from Lead Finder.", "ok");
  } catch (err) {
    setStatus(err instanceof Error ? err.message : "Save failed.", "err");
  } finally {
    copyBtn.disabled = false;
    saveBtn.disabled = false;
  }
}

fillOrigins();
copyBtn.addEventListener("click", () => void onCopy());
saveBtn.addEventListener("click", () => void onSave());
