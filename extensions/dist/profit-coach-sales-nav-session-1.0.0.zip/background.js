/**
 * Collect LinkedIn cookies in Cookie-Editor-compatible JSON shape for Apify.
 */

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "GET_LINKEDIN_COOKIES") {
    void collectLinkedInCookies()
      .then((cookies) => sendResponse({ ok: true, cookies }))
      .catch((err) =>
        sendResponse({
          ok: false,
          error: err instanceof Error ? err.message : "Cookie read failed.",
        })
      );
    return true; // async
  }
  return false;
});

async function collectLinkedInCookies() {
  const cookies = await chrome.cookies.getAll({ domain: "linkedin.com" });
  if (!cookies.length) {
    throw new Error(
      "No LinkedIn cookies found. Open linkedin.com / Sales Navigator and log in first."
    );
  }

  const hasLiAt = cookies.some((c) => c.name === "li_at" && c.value);
  if (!hasLiAt) {
    throw new Error(
      "LinkedIn login cookie (li_at) missing. Log into LinkedIn in this browser, then try again."
    );
  }

  // Cookie-Editor export shape (array of cookie objects).
  return cookies.map((c) => ({
    domain: c.domain,
    expirationDate: c.expirationDate,
    hostOnly: c.hostOnly,
    httpOnly: c.httpOnly,
    name: c.name,
    path: c.path,
    sameSite:
      c.sameSite === "no_restriction"
        ? "no_restriction"
        : c.sameSite === "lax"
          ? "lax"
          : c.sameSite === "strict"
            ? "strict"
            : "unspecified",
    secure: c.secure,
    session: c.session,
    storeId: c.storeId || "0",
    value: c.value,
  }));
}
